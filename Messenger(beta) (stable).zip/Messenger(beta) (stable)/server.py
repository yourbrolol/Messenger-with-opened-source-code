from flask import Flask, render_template, session, request, jsonify
from flask_socketio import SocketIO, emit
import uuid

# Initialize the Flask app and SocketIO (no specific async mode)
app = Flask(__name__)
app.secret_key = "Key"
socketio = SocketIO(app)  # Use default threading mode

# Dictionary to store client information and list to store message history
client_map = {}
message_history = []
 
# Route for the homepage
@app.route('/')
def home():
    # Generate a new client UUID if not present in the session
    if 'client_id' not in session:
        client_uuid = str(uuid.uuid4())
        session['client_id'] = client_uuid
        client_map[client_uuid] = f"Client {len(client_map) + 1}"

    # Render the index.html template
    return render_template('index.html')

# Route to change the client's username
@app.route('/ChangeUsername', methods=['POST'])
def change_username():
    client_uuid = session.get('client_id')
    if client_uuid is None:
        return jsonify({'status': 'error', 'message': 'Client not identified'})

    data = request.get_json()
    new_username = data.get('message', '')

    if new_username != '':
        old_username = client_map.get(client_uuid, "Unknown Client")
        client_map[client_uuid] = new_username
        
        # Notify all clients about the username change
        username_change_message = {
            'client_name': old_username,
            'new_username': new_username 
        }
        # Emit to all connected clients
        socketio.emit('username_changed', username_change_message)
        
        return jsonify({'status': 'Success', 'client_name': new_username})
    elif new_username != '':
        return jsonify({'status': 'error', 'message': 'Invalid username'})

# Route to handle message sending
@app.route('/message', methods=['POST'])
def send_message():
    client_uuid = session.get('client_id')
    if client_uuid is None:
        return jsonify({'status': 'error', 'message': 'Client not identified'})

    data = request.get_json()
    message = data.get('message', '')
    client_name = client_map.get(client_uuid, "Unknown Client")

    if len(message) > 199 or len(message) < 1:  # Assuming your limit is 200 characters
        return jsonify({'status': 'error', 'message': 'Message exceeds 200 characters limit'})

    # Store the message in history
    message_data = {'client_id': client_uuid, 'client_name': client_name, 'message': message}
    message_history.append(message_data)

    # Broadcast the new message to all clients
    socketio.emit('new_message', message_data, namespace='/', to=None)

    return jsonify({'status': 'Success!', 'client_id': client_uuid, 'client_name': client_name, 'message': message})

# WebSocket event to send message history when a client connects
@socketio.on('connect')
def handle_connect():
    emit('load_history', message_history)  # Send the message history to the newly connected client

    join_message = {'client_name': "Server", 'message': "We've got someone joined us!"}

    emit('new_message', join_message, broadcast=True)

@socketio.on('disconnect')
def handle_disconnect():
    client_uuid = session.get('client_id')

    if client_uuid is not None:
        client_name = client_map.get(client_uuid, "Unknown Client")
        
        # Create a leave message
        leave_message = {'client_name': "Server", 'message': f'{client_name} has left the chat'}
        
        # Add the leave message to message history
        message_history.append(leave_message)

        # Broadcast the leave message to all clients
        socketio.emit('new_message', leave_message, skip_sid=request.sid)

        # Clean up the client_map
        if client_uuid in client_map:
            del client_map[client_uuid]

# Run the app with SocketIO using default async mode
if __name__ == '__main__':
    socketio.run(app, debug=True)
