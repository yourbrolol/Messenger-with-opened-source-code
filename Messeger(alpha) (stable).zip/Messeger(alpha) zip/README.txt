Hello! Thanks for downloading my program. I will show u there how to launch it and host it.

So, first step u gotta right click on folder named "Messenger(alpha) (stable version)" then u gotta find the "open in terminal" or "open in powershell" option. (retry clicking if you dont see it). After clicking on that option, type that: Python server.py

It will launch the server. Then, hold ctrl button and left click the link near "Running on {link}", then u will open the messenger in browser.

To share the link, u need to download and setup ngrok soft. Youtube tutorials will help you.

Thats okay that it says "WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead." cuz idk how to disable that(u can try helping me by dm'ing me on my discord account @yourbrolol)

Thats it.

I hope you'll like it.